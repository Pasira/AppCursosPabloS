package com.example.pasir.appgaleria;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ResourceBundle;
import java.util.ServiceConfigurationError;

public class MainActivity extends AppCompatActivity {

    private EditText Username;
    private EditText Password;
    private Button Login;
    private Button Registro;
    private TextView Info;
    private int counter = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username = (EditText) findViewById(R.id.etUsername);
        Password = (EditText) findViewById(R.id.etPassword);
        Login = (Button) findViewById(R.id.btnLogin);
        Registro = (Button) findViewById(R.id.btnRegistro);
        Info = (TextView) findViewById(R.id.tvInfo);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarSesion(Username.getText().toString(), Password.getText().toString());
            }
        });

        Registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ResgistroActivity.class);
                startActivity(intent);
            }
        });
    }

    private void iniciarSesion(String email, String pass){
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                    //Toast de Bienvenida:
                    Toast.makeText(MainActivity.this, "Bienvenido MY FRIEND", Toast.LENGTH_SHORT).show();

                    startActivity(intent);
                }else{
                    counter--;

                    //Toast de log in incorrecto:
                    Toast.makeText(MainActivity.this, "El email o contraseña son incorrectos", Toast.LENGTH_SHORT).show();

                    Info.setText("Intentos restantes " + String.valueOf(counter));

                    if (counter == 0){
                        //Toast Fin de intentos restantes:
                        Toast.makeText(MainActivity.this, "Se acabaron las oportunidades...", Toast.LENGTH_SHORT).show();

                        Login.setEnabled(false);
                    }
                }
            }
        });

    }
}
