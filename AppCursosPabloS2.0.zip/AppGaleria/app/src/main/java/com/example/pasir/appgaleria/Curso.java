package com.example.pasir.appgaleria;

// CLASE PARA CURSOS

public class Curso {

    private String title;
    private String categoria;
    private String descripcion;
    private int miniatura;

    public Curso() {
    }

    public Curso(String title, String categoria, String descripcion, int miniatura) {
        this.title = title;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.miniatura = miniatura;
    }

    public Curso(String title, String descripcion, int miniatura) {
        this.title = title;
        this.descripcion = descripcion;
        this.miniatura = miniatura;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getMiniatura() {
        return miniatura;
    }

    public String getCategoria() {
        return categoria;
    }

    //Setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setMiniatura(int miniatura) {
        this.miniatura = miniatura;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}
