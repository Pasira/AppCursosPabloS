package com.example.pasir.appgaleria;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import javax.xml.transform.Templates;

public class CursoActivity extends AppCompatActivity {

    private TextView tvtitulo, tvcategoria, tvdescripcion;
    private ImageView miniatura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_curso);

        tvtitulo = (TextView) findViewById(R.id.id_titulo);
        tvdescripcion = (TextView) findViewById(R.id.id_descripcion);
        tvcategoria = (TextView) findViewById(R.id.id_categoria);
        miniatura = (ImageView) findViewById(R.id.id_curso);

        //Pasaremos los datos
        Intent intent = getIntent();
        String titulo = intent.getExtras().getString("Titulo");
        String categoria = intent.getExtras().getString("Categoria");
        String descripcion = intent.getExtras().getString("Descripcion");
        int imagen = intent.getExtras().getInt("Miniatura");

        //Le daremos un valor
        tvtitulo.setText(titulo);
        tvcategoria.setText(categoria);
        tvdescripcion.setText(descripcion);
        miniatura.setImageResource(imagen);

    }
}
