package com.example.pasir.appgaleria;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

//ACTIVITY QUE LANZA EL SPLASH ART DE LA APLICACIÓN:

public class SplashActivity extends AppCompatActivity {

    //DECLARACIÓN DE VARIABLES:
    private int SLEEP_TIMER = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_splash);
        getSupportActionBar().hide();
        LanzadorLogo LanzadorLogo = new LanzadorLogo(); //CREACIÓN DEL OBJETO
        LanzadorLogo.start();   //LLAMADA AL MÉTODO LANZAR LOGO

    }

    private class LanzadorLogo extends Thread{
        public void run(){
            try{
                sleep(1000 * SLEEP_TIMER);  //INDICAMOS EL TIEMPO QUE QUEREMOS QUE TARDE
            }catch(InterruptedException e){
                e.printStackTrace();
            }

            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);  //PASA AL ACTIVITY PRINCIPAL DE INICIO DE SESIÓN
            SplashActivity.this.finish();

        }
    }
}
