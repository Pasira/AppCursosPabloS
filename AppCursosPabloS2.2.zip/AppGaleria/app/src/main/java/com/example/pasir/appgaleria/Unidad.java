package com.example.pasir.appgaleria;

public class Unidad {

    private String titulo;
    private String videoPath;

    public Unidad() {
        titulo = "unidadDefault";
        videoPath = "rutaDefault";
    }

    public Unidad(String titulo, String videoPath) {
        this.titulo = titulo;
        this.videoPath = videoPath;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getVideoPath() {
        return videoPath;
    }

    public void setVideoPath(String videoPath) {
        this.videoPath = videoPath;
    }
}
