package com.example.pasir.appgaleria;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

//ACTIVITY QUE SE INICIARA, CUANDO HAGAN EL LOG IN O SE REGISTREN Y SE MUESTREN TODOS LOS CURSOS.

/**
 * Clase SecondActivity.
 */
public class SecondActivity extends AppCompatActivity {

    /**
     * Vector ListaCurso.
     */
    List<Curso> listaCurso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        /*Vector que mostrara los cursos con los parámetros que queremos que tenga (de la clase Curso)*/
        listaCurso = new ArrayList<>();

        //Creaciones en la base de datos de Firebase
        ArrayList<String> docentes = new ArrayList<>();
        docentes.add("Jcbs");
        docentes.add("Antonio");

        ArrayList <Unidad> unidadesDeLaSeccion1 = new ArrayList<>();
        unidadesDeLaSeccion1.add(new Unidad("UnidadSeccion1.1", "ruta1"));
        unidadesDeLaSeccion1.add(new Unidad("UnidadSeccion1.2", "ruta2"));

        ArrayList <Unidad> unidadesDeLaSeccion2 = new ArrayList<>();
        unidadesDeLaSeccion2.add(new Unidad("UnidadSeccion2.1", "ruta1"));
        unidadesDeLaSeccion2.add(new Unidad("UnidadSeccion2.2", "ruta2"));

        ArrayList<Seccion> secciones1 = new ArrayList<>();
        secciones1.add( new Seccion("Seccion1", unidadesDeLaSeccion1));
        secciones1.add( new Seccion("Seccion2", unidadesDeLaSeccion1));

        ArrayList<Seccion> secciones2 = new ArrayList<>();
        secciones2.add( new Seccion("Seccion3", unidadesDeLaSeccion2));
        secciones2.add( new Seccion("Seccion4", unidadesDeLaSeccion2));


        /*Vector que mostrara los cursos con los parámetros que queremos que tenga (de la clase Curso)*/
        listaCurso.add(new Curso("Acceso a Datos", "online", "basico", docentes, secciones1, R.drawable.accesodatos));
        listaCurso.add(new Curso("Entorno de desarrollo", "online", "basico", docentes, secciones2, R.drawable.entornodedesarrollo));


        //Llamada a la base de datos y a partir de donde queremos que coja
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference ref = db.getReference("cursos");
        ref.setValue(listaCurso);


        //Asignaremos los valores para poder mostrarlos
        RecyclerView myrv = (RecyclerView) findViewById(R.id.reciclerview);
        AdapdatorRV myAdaptador = new AdapdatorRV(this,listaCurso);
        myrv.setLayoutManager(new GridLayoutManager(this,3));
        myrv.setAdapter(myAdaptador);


    }
}
