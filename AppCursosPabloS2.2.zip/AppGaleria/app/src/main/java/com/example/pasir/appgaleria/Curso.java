package com.example.pasir.appgaleria;

// CLASE PARA CURSOS

import java.util.ArrayList;

/**
 * Clase Curso.
 */
public class Curso {

    String titulo;
    String tipo;
    String nivel;
    ArrayList<String> docentes;
    ArrayList<Seccion> secciones;
    private int  miniatura;

    public Curso(String titulo, String tipo, String nivel, ArrayList<String> docentes, ArrayList<Seccion> secciones, int miniatura) {
        this.titulo = titulo;
        this.tipo = tipo;
        this.nivel = nivel;
        this.docentes = docentes;
        this.secciones = secciones;
        this.miniatura = miniatura;
    }

    public Curso() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public ArrayList<String> getDocentes() {
        return docentes;
    }

    public void setDocentes(ArrayList<String> docentes) {
        this.docentes = docentes;
    }

    public ArrayList<Seccion> getSecciones() {
        return secciones;
    }

    public void setSecciones(ArrayList<Seccion> secciones) {
        this.secciones = secciones;
    }

    public int  getMiniatura() {
        return miniatura;
    }

    public void setMiniatura(int miniatura) {
        this.miniatura = miniatura;
    }
}
