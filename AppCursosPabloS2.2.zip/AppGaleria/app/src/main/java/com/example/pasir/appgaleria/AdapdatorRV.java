package com.example.pasir.appgaleria;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

/**
 * Clase AdapdatorRv.
 */
public class AdapdatorRV extends RecyclerView.Adapter<AdapdatorRV.MyViewHolder> {

    private Context mContext;
    private List<Curso> datos;

    /**
     * Constructor por parametros Adapdator rv.
     *
     * @param mContext igual a mContext
     * @param datos    igual a datos
     */
    public AdapdatorRV(Context mContext, List<Curso> datos) {
        this.mContext = mContext;
        this.datos = datos;
    }

    //Para asociarlo con el layout de cardviews
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        view = mInflater.inflate(R.layout.cardviews,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int i) {

        myViewHolder.tv_titulo_curso.setText(datos.get(i).getTipo());
        myViewHolder.img_curso_miniatura.setImageResource(datos.get(i).getMiniatura());


       /* Bitmap myBitmap = BitmapFactory.decodeFile(datos.get(i).getMiniatura());
        myViewHolder.img_curso_miniatura.setImageBitmap(myBitmap);*/

        // Set click listener:
        myViewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext,CursoActivity.class);

                //Para pasar los datos a la actividad de cursos
                intent.putExtra("Titulo", datos.get(i).getTitulo());
                intent.putExtra("Categoria", datos.get(i).getTipo());
                intent.putExtra("Sección", datos.get(i).getSecciones());
                intent.putExtra("Miniatura", datos.get(i).getMiniatura());
                mContext.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    /**
     * Clase estatica MyViewHolder.
     */
    public static class MyViewHolder extends RecyclerView.ViewHolder {

        /**
         * Un tv_titulo_curso.
         */
        TextView tv_titulo_curso;
        /**
         * Un img_curso_miniatura.
         */
        ImageView img_curso_miniatura;
        /**
         * Un card_view.
         */
        CardView cardView;

        /**
         * Intanciamos un nuevo MyViewHolder.
         *
         * @param itemView igual a itemView
         */
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_titulo_curso = (TextView) itemView.findViewById(R.id.titulo_curso);
            img_curso_miniatura = (ImageView) itemView.findViewById(R.id.imagen_curso);
            cardView = (CardView) itemView.findViewById(R.id.cardView_id);
        }
    }
}
