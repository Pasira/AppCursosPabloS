package com.example.pasir.appgaleria;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.net.UnknownServiceException;

/**
 * Clase ResgistroActivity.
 */
public class ResgistroActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText Email;
    private EditText Password;
    private Button Registrarse;

    /**
     * Authentication de Firebase.
     */
    FirebaseAuth.AuthStateListener authentication;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resgistro);

        // Declaracion
        Email = (EditText) findViewById(R.id.etUsername);
        Password = (EditText) findViewById(R.id.etPassword);
        Registrarse = (Button) findViewById(R.id.btnRegistrarse);

        Registrarse.setOnClickListener(this);

        authentication = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if(user != null){
                    System.out.println("Sesión iniciada con email: "+ user.getEmail());
                }else{
                    System.out.println("Sesión cerrada");
                }
            }
        };

    }

    private void registrar(String email, String pass) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    //Toast al Registrarse:
                    Toast.makeText(ResgistroActivity.this, "Te has registrado correcatmente", Toast.LENGTH_SHORT).show();


                    //Pasa directamente a la activity de registro:
                    Intent intent = new Intent(ResgistroActivity.this, SecondActivity.class);
                    startActivity(intent);

                } else {
                    //Toast Fail Inicio:
                    Toast.makeText(ResgistroActivity.this, "No te has registrado correctamente", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        String email = Email.getText().toString();
        String pass = Password.getText().toString();

        registrar(email, pass);
    }

    //Verificacion:
    @Override
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(authentication);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(authentication!=null){
            FirebaseAuth.getInstance().removeAuthStateListener(authentication);
        }
    }
}
