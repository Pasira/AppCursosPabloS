package com.example.pasir.appgaleria;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import javax.xml.transform.Templates;

/**
 * Clase CursoActivity.
 */
public class CursoActivity extends AppCompatActivity {

    private TextView tvtitulo, tvtipo, tvseccion;
    private ImageView miniatura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_curso);

        tvtitulo = (TextView) findViewById(R.id.id_titulo);
        tvseccion = (TextView) findViewById(R.id.id_descripcion);
        tvtipo = (TextView) findViewById(R.id.id_categoria);
        miniatura = (ImageView) findViewById(R.id.id_curso);

        //Pasaremos los datos
        Intent intent = getIntent();
        String titulo = intent.getExtras().getString("Titulo");
        String tipo = intent.getExtras().getString("Categoria");
        String seccion = intent.getExtras().getString("Seccion");
        int imagen = intent.getExtras().getInt("Miniatura");

        //Le daremos un valor
        tvtitulo.setText(titulo);
        tvtipo.setText(tipo);
        tvseccion.setText(seccion);
        miniatura.setImageResource(imagen);

    }
}
