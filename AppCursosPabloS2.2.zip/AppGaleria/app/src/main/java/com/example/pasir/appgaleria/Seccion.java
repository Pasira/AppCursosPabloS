package com.example.pasir.appgaleria;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Seccion {
    private String titulo;
    private ArrayList<Unidad> unidades;

    public Seccion() {
        titulo = "default;";
        unidades = null;
    }

    public Seccion(String titulo, ArrayList<Unidad> unidades) {
        this.titulo = titulo;
        this.unidades = unidades;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public ArrayList<Unidad> getUnidades() {
        return unidades;
    }

    public void setUnidades(ArrayList<Unidad> unidades) {
        this.unidades = unidades;
    }
}
