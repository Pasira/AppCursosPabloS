package com.example.pasir.appgaleria;

// CLASE PARA CURSOS

/**
 * Clase Curso.
 */
public class Curso {

    private String titulo;
    private String categoria;
    private String descripcion;
    private int miniatura;

    /**
     * Constructor por defecto Curso.
     */
    public Curso() {
    }

    /**
     * Constructor por parametros Curso.
     *
     * @param titulo      igual a titulo
     * @param categoria   igual a categoria
     * @param descripcion igual a descripcion
     * @param miniatura   igual a miniatura
     */
    public Curso(String titulo, String categoria, String descripcion, int miniatura) {
        this.titulo = titulo;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.miniatura = miniatura;
    }


// Getters

    /**
     * Gets titulo.
     *
     * @return titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Gets descripcion.
     *
     * @return descripcion
     */
    public String getDescripcion() {
        return descripcion;
    }

    /**
     * Gets miniatura.
     *
     * @return miniatura
     */
    public int getMiniatura() {
        return miniatura;
    }

    /**
     * Gets categoria.
     *
     * @return categoria
     */
    public String getCategoria() {
        return categoria;
    }


//Setters

    /**
     * Sets titulo.
     *
     * @param titulo de titulo
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Sets descripcion.
     *
     * @param descripcion de descripcion
     */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
     * Sets miniatura.
     *
     * @param miniatura de miniatura
     */
    public void setMiniatura(int miniatura) {
        this.miniatura = miniatura;
    }

    /**
     * Sets categoria.
     *
     * @param categoria de categoria
     */
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}
