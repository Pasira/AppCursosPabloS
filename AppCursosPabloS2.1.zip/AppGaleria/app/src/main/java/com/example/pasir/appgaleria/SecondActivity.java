package com.example.pasir.appgaleria;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

//ACTIVITY QUE SE INICIARA, CUANDO HAGAN EL LOG IN O SE REGISTREN Y SE MUESTREN TODOS LOS CURSOS.

/**
 * Clase SecondActivity.
 */
public class SecondActivity extends AppCompatActivity {

    /**
     * Vector ListaCurso.
     */
    List<Curso> listaCurso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        /*Vector que mostrara los cursos con los parámetros que queremos que tenga (de la clase Curso)*/
        listaCurso = new ArrayList<>();
        listaCurso.add(new Curso("Curso 1", "online","Descripción del libro", R.drawable.curso1));
        listaCurso.add(new Curso("Curso 2", "online","Descripción del libro", R.drawable.curso2));
        listaCurso.add(new Curso("Curso 3", "online","Descripción del libro", R.drawable.curso3));
        listaCurso.add(new Curso("Curso 4", "online","Descripción del libro", R.drawable.curso4));
        listaCurso.add(new Curso("Curso 5", "online","Descripción del libro", R.drawable.curso5));
        listaCurso.add(new Curso("Curso 6", "online","Descripción del libro", R.drawable.curso6));
        listaCurso.add(new Curso("Curso 1", "online","Descripción del libro", R.drawable.curso1));
        listaCurso.add(new Curso("Curso 2", "online","Descripción del libro", R.drawable.curso2));
        listaCurso.add(new Curso("Curso 3", "online","Descripción del libro", R.drawable.curso3));
        listaCurso.add(new Curso("Curso 4", "online","Descripción del libro", R.drawable.curso4));
        listaCurso.add(new Curso("Curso 5", "online","Descripción del libro", R.drawable.curso5));
        listaCurso.add(new Curso("Curso 6", "online","Descripción del libro", R.drawable.curso6));

        //Asignaremos los valores para poder mostrarlos
        RecyclerView myrv = (RecyclerView) findViewById(R.id.reciclerview);
        AdapdatorRV myAdaptador = new AdapdatorRV(this,listaCurso);
        myrv.setLayoutManager(new GridLayoutManager(this,3));
        myrv.setAdapter(myAdaptador);


    }
}
